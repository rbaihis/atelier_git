#ifndef JOUER_H_
#define JOUER_H_

void jouer(int *c ,int *a, SDL_Surface *screen);



#endif
